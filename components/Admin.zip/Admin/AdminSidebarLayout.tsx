"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarInset,
} from "@/components/ui/sidebar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import {
  LayoutDashboard,
  Users,
  Settings,
  BarChart3,
  Database,
  Shield,
  User,
  LogOut,
  UserPlus,
  ChevronDown,
  Bell,
  Cog,
} from "lucide-react"

interface AdminSidebarLayoutProps {
  children: React.ReactNode
}

const AdminSidebarLayout = ({ children }: AdminSidebarLayoutProps) => {
  const [user, setUser] = useState<any>(null)
  const [notifications, setNotifications] = useState(3)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }
  }, [])

  const handleLogout = () => {
    localStorage.clear()
    router.push("/")
  }

  const menuItems = [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      path: "/admin/dashboard",
      active: pathname === "/admin/dashboard",
    },
    {
      title: "User Management",
      icon: Users,
      path: "/admin/users",
      active: pathname === "/admin/users",
      // badge: "24",
    },
    {
      title: "Analytics",
      icon: BarChart3,
      path: "/admin/analytics",
      active: pathname === "/admin/analytics",
    },
    {
      title: "AI Model",
      icon: Cog,
      path: "/admin/change-model",
      active: pathname === "/admin/change-model",
      // badge: "New",
    },
    {
      title: "System Settings",
      icon: Settings,
      path: "/admin/settings",
      active: pathname === "/admin/settings",
    },
    {
      title: "Data Management",
      icon: Database,
      path: "/admin/data",
      active: pathname === "/admin/data",
    },
    {
      title: "Security",
      icon: Shield,
      path: "/admin/security",
      active: pathname === "/admin/security",
    },
  ]

  const AppSidebar = () => (
    <Sidebar className="border-r border-gray-200">
      <SidebarHeader className="border-b border-gray-200 p-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-orange-600 rounded-lg flex items-center justify-center">
            <Shield className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">SmartCT Admin</h2>
            <p className="text-sm text-gray-500">Administrative Console</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="p-4">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    isActive={item.active}
                    className="w-full justify-start px-4 py-3 text-left hover:bg-red-50 hover:text-red-700 data-[active=true]:bg-red-100 data-[active=true]:text-red-700 data-[active=true]:font-semibold"
                  >
                    <a href={item.path} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <item.icon className="h-5 w-5" />
                        <span>{item.title}</span>
                      </div>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-gray-200">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="w-full justify-between px-4 py-3 h-auto hover:bg-gray-50">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                  <User className="h-4 w-4 text-white" />
                </div>
                <div className="text-left">
                  <p className="text-sm font-medium text-gray-900">{user?.firstName || user?.name || "Admin"}</p>
                  <p className="text-xs text-gray-500">Administrator</p>
                </div>
              </div>
              <ChevronDown className="h-4 w-4 text-gray-400" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuItem onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Sign Out
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => router.push("/signup")}>
              <UserPlus className="mr-2 h-4 w-4" />
              Add Admin
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarFooter>
    </Sidebar>
  )

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AppSidebar />
        <SidebarInset className="flex-1">
          <header className="sticky top-0 z-10 bg-white border-b border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <SidebarTrigger className="lg:hidden" />
                <Badge className="bg-red-100 text-red-800">Admin Mode</Badge>
              </div>
              <div className="flex items-center space-x-4">
                <Button variant="ghost" size="sm" className="relative">
                  <Bell className="h-4 w-4" />
                  {notifications > 0 && (
                    <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center p-0">
                      {notifications}
                    </Badge>
                  )}
                </Button>
              </div>
            </div>
          </header>
          <main className="flex-1">{children}</main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}

export default AdminSidebarLayout
