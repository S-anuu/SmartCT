"use client"

import { useState } from "react"
import AdminSidebarLayout from "./AdminSidebarLayout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert } from "@/components/ui/alert"
import {
  Users,
  Activity,
  FileText,
  AlertTriangle,
  TrendingUp,
  Server,
  Database,
  Clock,
  CheckCircle,
  XCircle,
  Settings,
  BarChart3,
} from "lucide-react"

const AdminDashboard = () => {
  const [systemStats, setSystemStats] = useState({
    totalUsers: 1247,
    activeUsers: 892,
    totalScans: 5634,
    todayScans: 127,
    systemUptime: "99.8%",
    modelAccuracy: 94.2,
    storageUsed: 78,
    processingQueue: 3,
  })

  const [recentActivity, setRecentActivity] = useState([
    {
      id: 1,
      type: "scan",
      user: "Dr. Sarah Johnson",
      action: "Completed CT scan analysis",
      time: "2 minutes ago",
      status: "success",
    },
    {
      id: 2,
      type: "user",
      user: "Admin",
      action: "Created new user account",
      time: "15 minutes ago",
      status: "info",
    },
    {
      id: 3,
      type: "system",
      user: "System",
      action: "Model accuracy updated",
      time: "1 hour ago",
      status: "success",
    },
    {
      id: 4,
      type: "alert",
      user: "System",
      action: "High processing queue detected",
      time: "2 hours ago",
      status: "warning",
    },
  ])

  const [systemAlerts, setSystemAlerts] = useState([
    {
      id: 1,
      type: "warning",
      title: "High Storage Usage",
      message: "Storage is at 78% capacity. Consider archiving old scans.",
      time: "1 hour ago",
    },
    {
      id: 2,
      type: "info",
      title: "Model Update Available",
      message: "New AI model version 2.1.3 is available for deployment.",
      time: "3 hours ago",
    },
  ])

  const statsCards = [
    {
      title: "Total Users",
      value: systemStats.totalUsers.toLocaleString(),
      change: "+12%",
      changeType: "positive",
      icon: Users,
      color: "bg-blue-500",
    },
    {
      title: "Active Users",
      value: systemStats.activeUsers.toLocaleString(),
      change: "+8%",
      changeType: "positive",
      icon: Activity,
      color: "bg-green-500",
    },
    {
      title: "Total Scans",
      value: systemStats.totalScans.toLocaleString(),
      change: "+23%",
      changeType: "positive",
      icon: FileText,
      color: "bg-purple-500",
    },
    {
      title: "Today's Scans",
      value: systemStats.todayScans.toString(),
      change: "+15%",
      changeType: "positive",
      icon: TrendingUp,
      color: "bg-orange-500",
    },
  ]

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "scan":
        return <FileText className="h-4 w-4" />
      case "user":
        return <Users className="h-4 w-4" />
      case "system":
        return <Server className="h-4 w-4" />
      case "alert":
        return <AlertTriangle className="h-4 w-4" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "text-green-600"
      case "warning":
        return "text-yellow-600"
      case "error":
        return "text-red-600"
      case "info":
        return "text-blue-600"
      default:
        return "text-gray-600"
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "error":
        return <XCircle className="h-4 w-4 text-red-600" />
      case "info":
        return <CheckCircle className="h-4 w-4 text-blue-600" />
      default:
        return <Activity className="h-4 w-4 text-gray-600" />
    }
  }

  return (
    <AdminSidebarLayout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="p-6 space-y-8">
          {/* Header */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
              <p className="text-xl text-gray-600">System overview and management console</p>
            </div>
            <div className="flex items-center space-x-3">
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                System Online
              </Badge>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                {systemStats.processingQueue} in Queue
              </Badge>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {statsCards.map((stat, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
                  <div className={`p-2 rounded-full ${stat.color}`}>
                    <stat.icon className="h-4 w-4 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`text-sm font-medium ${
                        stat.changeType === "positive" ? "text-green-600" : "text-red-600"
                      }`}
                    >
                      {stat.change}
                    </span>
                    <span className="text-sm text-gray-500">from last month</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* System Health */}
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center">
                  <Server className="h-5 w-5 mr-2" />
                  System Health
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">System Uptime</span>
                    <Badge className="bg-green-100 text-green-800">{systemStats.systemUptime}</Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Model Accuracy</span>
                      <span className="text-sm font-bold text-gray-900">{systemStats.modelAccuracy}%</span>
                    </div>
                    <Progress value={systemStats.modelAccuracy} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Storage Usage</span>
                      <span className="text-sm font-bold text-gray-900">{systemStats.storageUsed}%</span>
                    </div>
                    <Progress value={systemStats.storageUsed} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2" />
                  System Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {systemAlerts.map((alert) => (
                    <Alert key={alert.id} className="border-l-4 border-l-yellow-400">
                      <div className="flex items-start space-x-3">
                        {getAlertIcon(alert.type)}
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{alert.title}</h4>
                          <p className="text-sm text-gray-600 mt-1">{alert.message}</p>
                          <p className="text-xs text-gray-500 mt-2">{alert.time}</p>
                        </div>
                      </div>
                    </Alert>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-gray-900 flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Recent Activity
              </CardTitle>
              <CardDescription>Latest system and user activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-center space-x-4 p-3 rounded-lg hover:bg-gray-50">
                    <div className={`p-2 rounded-full bg-gray-100 ${getStatusColor(activity.status)}`}>
                      {getActivityIcon(activity.type)}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                      <p className="text-sm text-gray-600">by {activity.user}</p>
                    </div>
                    <span className="text-xs text-gray-500">{activity.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-gray-900">Quick Actions</CardTitle>
              <CardDescription>Common administrative tasks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Button className="h-16 flex-col space-y-2 bg-blue-600 hover:bg-blue-700 text-white">
                  <Users className="h-5 w-5" />
                  <span>Manage Users</span>
                </Button>
                <Button className="h-16 flex-col space-y-2 bg-green-600 hover:bg-green-700 text-white">
                  <BarChart3 className="h-5 w-5" />
                  <span>View Analytics</span>
                </Button>
                <Button className="h-16 flex-col space-y-2 bg-purple-600 hover:bg-purple-700 text-white">
                  <Settings className="h-5 w-5" />
                  <span>System Settings</span>
                </Button>
                <Button className="h-16 flex-col space-y-2 bg-orange-600 hover:bg-orange-700 text-white">
                  <Database className="h-5 w-5" />
                  <span>Backup Data</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminSidebarLayout>
  )
}

export default AdminDashboard
