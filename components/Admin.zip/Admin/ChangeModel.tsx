"use client"

import { useState } from "react"
import AdminSidebarLayout from "./AdminSidebarLayout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Cog,
  Download,
  Upload,
  CheckCircle,
  AlertTriangle,
  BarChart3,
  Clock,
  Database,
  Zap,
  RefreshCw,
} from "lucide-react"

const ChangeModel = () => {
  const [currentModel, setCurrentModel] = useState({
    name: "SmartCT AI v2.1.2",
    version: "2.1.2",
    accuracy: 94.2,
    deployedDate: "2025-01-15",
    status: "Active",
    performance: {
      // removed avgProcessingTime, cpuUsage and memoryUsage 
    },
  })

  const [availableModels, setAvailableModels] = useState([
    {
      id: 1,
      name: "SmartCT AI v2.1.3",
      version: "2.1.3",
      accuracy: 95.1,
      releaseDate: "2025-01-20",
      status: "Available",
      improvements: [
        "Improved liver trauma detection by 8%",
        "Reduced false positives by 12%",
        "Enhanced processing speed by 15%",
      ],
      size: "2.4 GB",
    },
    {
      id: 2,
      name: "SmartCT AI v2.2.0-beta",
      version: "2.2.0-beta",
      accuracy: 96.3,
      releaseDate: "2025-01-25",
      status: "Beta",
      improvements: [
        "New spleen injury classification",
        "Multi-organ trauma correlation",
        "Real-time confidence scoring",
      ],
      size: "2.8 GB",
    },
  ])

  const [isDeploying, setIsDeploying] = useState(false)
  const [deployProgress, setDeployProgress] = useState(0)

  const handleDeployModel = (model: any) => {
    setIsDeploying(true)
    setDeployProgress(0)

    // Simulate deployment progress
    const interval = setInterval(() => {
      setDeployProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsDeploying(false)
          setCurrentModel({
            name: model.name,
            version: model.version,
            accuracy: model.accuracy,
            deployedDate: new Date().toISOString().split("T")[0],
            status: "Active",
            performance: currentModel.performance,
          })
          return 100
        }
        return prev + 10
      })
    }, 300)
  }

  const modelMetrics = [
  {
    title: "Model Accuracy",
    value: `${currentModel.accuracy}%`,
    icon: BarChart3,
    color: "text-green-600",
  },
]

  return (
    <AdminSidebarLayout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="p-6 space-y-8">
          {/* Header */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">AI Model Management</h1>
              <p className="text-xl text-gray-600">Manage and deploy AI models for trauma detection</p>
            </div>
            <div className="flex items-center space-x-3">
              <Badge className="bg-green-100 text-green-800">
                <CheckCircle className="h-3 w-3 mr-1" />
                Model Active
              </Badge>
            </div>
          </div>

          {/* Current Model Status */}
          <Card className="border-0 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl font-semibold text-gray-900 flex items-center">
                <Cog className="h-6 w-6 mr-3" />
                Current Model
              </CardTitle>
              <CardDescription>Currently deployed AI model information and performance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{currentModel.name}</h3>
                    <p className="text-gray-600">Version {currentModel.version}</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Deployed</span>
                      <span className="text-sm font-medium">{currentModel.deployedDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Status</span>
                      <Badge className="bg-green-100 text-green-800">{currentModel.status}</Badge>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <div className="grid grid-cols-2 gap-4 max-w-md w-full">
                    {modelMetrics.map((metric, index) => (
                      <div key={index} className="bg-gray-50 rounded-lg p-4">
                        <div className="flex items-center space-x-2 mb-2">
                          <metric.icon className={`h-4 w-4 ${metric.color}`} />
                          <span className="text-sm font-medium text-gray-700">{metric.title}</span>
                        </div>
                        <p className={`text-lg font-bold ${metric.color}`}>{metric.value}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {isDeploying && (
                <Alert className="border-blue-200 bg-blue-50">
                  <RefreshCw className="h-4 w-4 text-blue-600 animate-spin" />
                  <AlertDescription className="text-blue-800">
                    <div className="space-y-2">
                      <p>Deploying new model... {deployProgress}%</p>
                      <Progress value={deployProgress} className="h-2" />
                    </div>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>

          </Card>

          {/* Available Models */}
          <Card className="border-0 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl font-semibold text-gray-900">Available Models</CardTitle>
              <CardDescription>Deploy new AI models or rollback to previous versions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {availableModels.map((model) => (
                  <Card key={model.id} className="border border-gray-200">
                    <CardContent className="p-6">
                      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                        <div className="space-y-3">
                          <div className="flex items-center space-x-3">
                            <h3 className="text-lg font-semibold text-gray-900">{model.name}</h3>
                            <Badge
                              className={
                                model.status === "Beta" ? "bg-yellow-100 text-yellow-800" : "bg-blue-100 text-blue-800"
                              }
                            >
                              {model.status}
                            </Badge>
                          </div>
                          <div className="grid md:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Accuracy:</span>
                              <span className="ml-2 font-semibold text-green-600">{model.accuracy}%</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Release Date:</span>
                              <span className="ml-2 font-medium">{model.releaseDate}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Size:</span>
                              <span className="ml-2 font-medium">{model.size}</span>
                            </div>
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-900 mb-2">Key Improvements:</h4>
                            <ul className="space-y-1">
                              {model.improvements.map((improvement, index) => (
                                <li key={index} className="text-sm text-gray-600 flex items-center">
                                  <CheckCircle className="h-3 w-3 text-green-600 mr-2 flex-shrink-0" />
                                  {improvement}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                        <div className="flex flex-col space-y-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                                <Upload className="h-4 w-4 mr-2" />
                                Deploy Model
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Deploy {model.name}?</DialogTitle>
                                <DialogDescription>
                                  This will replace the current model and may cause a brief service interruption. Are
                                  you sure you want to proceed?
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <Alert className="border-yellow-200 bg-yellow-50">
                                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                                  <AlertDescription className="text-yellow-800">
                                    <strong>Warning:</strong> This action will immediately replace the current model.
                                    All active scans will be processed with the new model.
                                  </AlertDescription>
                                </Alert>
                                <div className="bg-gray-50 rounded-lg p-4">
                                  <h4 className="font-semibold mb-2">Deployment Details:</h4>
                                  <ul className="text-sm space-y-1">
                                    <li>• Estimated deployment time: 2-3 minutes</li>
                                    <li>• Service interruption: ~30 seconds</li>
                                    <li>• Automatic rollback on failure</li>
                                  </ul>
                                </div>
                              </div>
                              <DialogFooter>
                                <Button
                                  onClick={() => handleDeployModel(model)}
                                  disabled={isDeploying}
                                  className="bg-blue-600 hover:bg-blue-700"
                                >
                                  {isDeploying ? "Deploying..." : "Deploy Model"}
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                          <Button variant="outline">
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Removed Performance Analytics section */}
        </div>
      </div>
    </AdminSidebarLayout>
  )
}

export default ChangeModel
